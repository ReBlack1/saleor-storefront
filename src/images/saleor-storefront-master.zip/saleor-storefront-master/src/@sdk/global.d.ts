declare interface Window {
  PasswordCredential: any;
}

declare interface Navigator {
  credentials: any;
}
