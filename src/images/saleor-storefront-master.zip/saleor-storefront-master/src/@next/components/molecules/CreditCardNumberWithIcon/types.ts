import { CCProviders } from "@components/atoms";

export interface IProps {
  creditCardProvider: CCProviders;
  last4Digits: number;
}
