import { ISelect } from "@components/atoms";
export interface IProps extends ISelect {
  label: string;
}
