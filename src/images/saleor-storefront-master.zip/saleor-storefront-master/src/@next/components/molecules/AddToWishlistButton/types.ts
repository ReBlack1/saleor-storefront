export interface IProps {
  added: boolean;
  onClick: () => void;
}
