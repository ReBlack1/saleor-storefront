export interface IProps {
  links: string[];
  active: string;
}
