import { ProductList_products_edges_node } from "@sdk/queries/types/ProductList";

export interface IProps {
  product: ProductList_products_edges_node;
}
