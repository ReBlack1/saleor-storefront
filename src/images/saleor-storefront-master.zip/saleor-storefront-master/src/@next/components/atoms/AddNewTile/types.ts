export interface IProps {
  type: string;
  onClick?: () => void;
}
