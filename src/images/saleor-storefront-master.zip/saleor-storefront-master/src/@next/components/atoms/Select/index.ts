export * from "./Select";
export { IProps as ISelect } from "./types";
