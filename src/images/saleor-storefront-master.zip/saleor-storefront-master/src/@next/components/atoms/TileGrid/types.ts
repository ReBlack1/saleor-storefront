export interface IProps {
  elements: React.ReactNode[];
  columns?: number;
}
