export interface IProps {
  alt?: string;
}
