export interface IProps {
  description: string;
  attributeValue: string;
}
