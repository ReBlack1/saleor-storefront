export const mockItemRoute = {
  name: "Route",
  page: "/",
};
