import { styled } from "@styles";

export const CreditCardIcon = styled.div`
  display: inline-block;
  vertical-align: middle;
`;
