import { IIconProps } from "../Icon";

export interface IProps extends IIconProps {
  onClick?: () => void;
}
