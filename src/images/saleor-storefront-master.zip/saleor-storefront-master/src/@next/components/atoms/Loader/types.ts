export interface IProps {
  fullScreen?: boolean;
}
