const textBlock = `{"blocks": [{"key": "", "data": {}, "text": "They say polo is the sport of kings.Or was that stamp collecting ? Either way, this shirt is fit for a king of Saturday night.", "type": "unstyled", "depth": 0, "entityRanges": [], "inlineStyleRanges": []}], "entityMap": {}}`;
export default textBlock;
