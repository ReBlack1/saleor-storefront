const list = `
{
  "blocks": [
    {
      "data": {},
      "depth": 0,
      "entityRanges": [],
      "inlineStyleRanges": [],
      "key": "8r8ss",
      "text": "ul",
      "type": "unordered-list-item"
    },
    {
      "data": {},
      "depth": 0,
      "entityRanges": [],
      "inlineStyleRanges": [],
      "key": "911hc",
      "text": "ol",
      "type": "ordered-list-item"
    }
  ]
}
`;

export default list;
