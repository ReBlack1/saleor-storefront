export * from "./Icon";
export { IProps as IIconProps } from "./types";
