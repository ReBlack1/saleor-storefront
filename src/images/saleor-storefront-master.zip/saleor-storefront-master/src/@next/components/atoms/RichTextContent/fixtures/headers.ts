const headers = `
{
  "blocks": [
    {
      "data": {},
      "depth": 0,
      "entityRanges": [],
      "inlineStyleRanges": [],
      "key": "aven6",
      "text": "h1",
      "type": "header-one"
    },
    {
      "data": {},
      "depth": 0,
      "entityRanges": [],
      "inlineStyleRanges": [],
      "key": "9rabl",
      "text": "h2",
      "type": "header-two"
    },
    {
      "data": {},
      "depth": 0,
      "entityRanges": [],
      "inlineStyleRanges": [],
      "key": "bv0ac",
      "text": "h3",
      "type": "header-three"
    }
  ]
}
`;
export default headers;
