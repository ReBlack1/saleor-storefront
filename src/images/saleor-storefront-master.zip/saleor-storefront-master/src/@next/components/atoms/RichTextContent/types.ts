export interface IProps {
  descriptionJson: string;
}
