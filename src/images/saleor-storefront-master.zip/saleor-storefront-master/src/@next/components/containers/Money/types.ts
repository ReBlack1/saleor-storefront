export interface IProps {
  money?: {
    amount: number;
    currency: string;
  };
  defaultValue?: string;
}
