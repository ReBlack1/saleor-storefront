import { ITaxedMoney } from "@types";

export interface IProps {
  taxedMoney?: ITaxedMoney;
  defaultValue?: string;
}
