import { IImage } from "@types";

export interface IProps {
  images: IImage[];
}
