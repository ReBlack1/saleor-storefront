export interface IProps {
  items: any;
}
