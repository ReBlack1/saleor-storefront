export const DEFAULT_PROPS = {
  disabledOptions: ["7 1/2"],
  options: [
    {
      label: "7",
      value: "7",
    },
    {
      label: "7 1/8",
      value: "7 1/8",
    },
    {
      label: "7 1/4",
      value: "7 1/4",
    },
    {
      label: "7 3/8",
      value: "7 3/84",
    },
    {
      label: "7 1/2",
      value: "7 1/2",
    },
    {
      label: "7 5/8",
      value: "7 5/8",
    },
    {
      label: "7 3/4",
      value: "7 3/4",
    },
    {
      label: "7 7/8",
      value: "7 7/8",
    },
    {
      label: "8",
      value: "8",
    },
  ],
  selectedOptions: ["7 1/8"],
};
