import { styled } from "@styles";

export const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
`;
