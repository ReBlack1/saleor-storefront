const utils = require("./utils");

module.exports = _plop => ({
  description: "Example generator",
  prompts: [
    // Put propmts here
  ],

  actions: answers => {
    const actions = [
      // Put actions here
    ];

    return actions;
  }
});
